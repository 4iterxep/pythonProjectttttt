from django.contrib import admin

from .models import Kuponi

admin.site.register(Kuponi)